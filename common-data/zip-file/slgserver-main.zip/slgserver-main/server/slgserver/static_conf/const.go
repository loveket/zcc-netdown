package static_conf

//军队武将数量
const ArmyGCnt = 3
